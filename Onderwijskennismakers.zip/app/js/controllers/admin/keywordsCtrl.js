module.exports = function ($scope, user) {

    var self = this;

    $scope.user = user;

};