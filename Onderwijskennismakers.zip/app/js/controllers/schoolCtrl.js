module.exports = function ($scope) {


};