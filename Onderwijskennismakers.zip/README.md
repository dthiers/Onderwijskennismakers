# Onderwijskennismakers
Repository project first semester, third year, 42IN11SOk


## Install Instructions

1. Get latest commit from GitHub
2. Run `npm install` in the root folder of the project
3. Run PrePros to convert .less files to .css
4. Run `grunt` in the root folder of the project
5. Go to "/#/" to see if its working
6. Download resources from Google Drive (https://drive.google.com/open?id=0By3xhlXaPWmOUmJRT1hHMU1Qejg)
7. Place the downloaded folder in the `/dist` folder
