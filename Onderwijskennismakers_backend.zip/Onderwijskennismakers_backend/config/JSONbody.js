
// User
{
  "firstName":"firstname",
  "lastName":"lastname",
  "email":"email",
  "password" : "password",
  "functionDescription" : "function description",
  "profileImage": "profile image",
  "createdAt": "2016-04-21",
  "lastUpdate" : "2016-04-21",
  "isAdmin" : 0,
  "isFrozen" : 0
}
